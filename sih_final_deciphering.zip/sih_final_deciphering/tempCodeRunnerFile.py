calculateaccuracy=tk.Button(
    #     results_page,
    #     text="Calculate accuracy",
    #     command=accuracy_cal,
    #     bg="black",
    #     fg="white",
    # )
    # calculateaccuracy.place(relx=0.5,rely=0.8)
    # label_accuracy=tk.Label(
    #     results_page,
    #     text="Accuracy",
    # )

    # print(accuracy_value)